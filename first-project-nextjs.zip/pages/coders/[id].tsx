import React from 'react';

export interface DetailCoderProp {

}

export default function DetailCoder (props : DetailCoderProp){
    return (
        <div>
             <h1> DetailCoder </h1>
        </div>
    )
}