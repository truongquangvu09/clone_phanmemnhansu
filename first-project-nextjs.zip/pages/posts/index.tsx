import React from 'react';

export interface PostPageAProps {

}

export default function PostPage (props : PostPageAProps){
    return (
        <div>
              Posts
        </div>
    )
}