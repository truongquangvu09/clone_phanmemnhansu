import React from 'react';

export interface CreatePostPageAProps {

}

export default function CreatePostPage (props : CreatePostPageAProps){
    return (
        <div>
              CreatePosts
        </div>
    )
}